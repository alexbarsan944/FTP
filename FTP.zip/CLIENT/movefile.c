#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
void mv(char file[1024], char location[1024])
{
    char ch;
    //char location[1024];
    //strcpy(location, "dir1/dir2");
    FILE *f = fopen(file, "r");
    if (f == NULL)
    {
        printf("Error in opening file..!!");
        exit(1);
    }

    char cwd[1024];
    if (getcwd(cwd, sizeof(cwd)) == NULL)
    {
        perror("getcwd() error");
    }
    strcat(cwd, "/");
    strcat(cwd, location);
    chdir(cwd);
    printf("%s\n", cwd);
    FILE *g = fopen(file, "w");

    if (g == NULL)
    {
        printf("couldnt find directory\n");
    }

    while (1)
    {
        ch = fgetc(f);
        if (ch == EOF)
            break;
        else
            fputc(ch, g);
    }
    fclose(f);
    fclose(g);
}
void main()
{
    mv("testfile", "dir1/dir2");
}
