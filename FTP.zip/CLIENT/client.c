#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <errno.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <netdb.h>
#include <string.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <time.h>
#include <fcntl.h>
#include <termios.h>
#include <arpa/inet.h>

#define red "\033[0;31m"
#define green "\033[0;32m"
#define yellow "\033[0;33m"
#define blue "\033[0;34m"
#define reset "\033[0m"
#define PATH_MAX 4096
#define MAX_LINE 4096

/* codul de eroare returnat de anumite apeluri */
extern int errno;
int logged;



int count_lines(char *name)
{
  FILE *f = fopen(name, "r");
  int lines_number = 0;
  for (int i = getc(f); i != EOF; i = getc(f))
    if (i == '\n')
      lines_number++;
  fclose(f);
  return lines_number + 1;
}
int sendfile(FILE *fp, int sockfd)
{
  ssize_t n, total = 0;
  char sendline[MAX_LINE] = {0};
  while ((n = fread(sendline, sizeof(char), MAX_LINE, fp)) > 0)
  {
    total += n;
    if (n != MAX_LINE && ferror(fp))
    {
      perror("Read File Error");
      exit(1);
    }
    if (send(sockfd, sendline, n, 0) == -1)
    {
      perror("Can't send file");
      exit(1);
    }
    memset(sendline, 0, MAX_LINE);
  }
  return 1;
}

int mv(char file[1024], char location[1024])
{
  char ch;
  FILE *f = fopen(file, "r");
  if (f == NULL)
  {
    printf("Error in opening file..!!");
    return 0;
  }

  char cwd[1024];
  if (getcwd(cwd, sizeof(cwd)) == NULL)
  {
    perror("getcwd() error");
    return -1;
  }

  char dest[1024];
  if (getcwd(dest, sizeof(dest)) == NULL)
  {
    perror("getcwd() error");
    return -2;
  }
  strcat(dest, "/");
  strcat(dest, location);
  chdir(dest);
  //printf("%s\n", dest);
  FILE *g = fopen(file, "w");

  if (g == NULL)
  {
    printf("couldnt open file\n");
    return -3;
  }
  char line[MAX_LINE] = {0};
  ssize_t n, total = 0;
  while ((n = fread(line, sizeof(char), MAX_LINE, f)) > 0)
  {
    total += n;
    if (n != MAX_LINE && ferror(f))
    {
      perror("Read File Error");
      break;
    }
    if (fwrite(line, sizeof(char), n, g) != n)
    {
      perror("Write File Error");
      break;
    }
    if (n < MAX_LINE)
      break;
    memset(line, 0, MAX_LINE);
  }

  chdir(cwd);
  remove(file);

  fclose(f);
  fclose(g);
  return 1;
}

int isDirectory(const char *path)
{
  struct stat statbuf;
  if (stat(path, &statbuf) != 0)
    return 0;
  return S_ISDIR(statbuf.st_mode);
}
int isExec(const char *path)
{
  struct stat sb;
  if (stat(path, &sb) != 0)
    return 0;
  return (sb.st_mode & S_IXUSR);
}

int makeDirectory(char *where, char *name)
{
  if (!isDirectory(where))
  {
    printf("This already exists.\n");
    fflush(stdout);
  }

  if (mkdir(name, 0777) == -1)
  {
    printf("%s\n", "Eroare la crearea directorului");
    return 0;
  }
  return 1;
}

 /*int unlink_cb(const char *fpath, const struct stat *sb, int typeflag, struct FTW *ftwbuf)
{
  int rv = remove(fpath);

  if (rv)
    perror(fpath);

  return rv;
}

int rmrf(char *path)
{
  return nftw(path, unlink_cb, 64, FTW_DEPTH | FTW_PHYS);
}
    Pentru functiile unlink_cb si rmrf:
https://riptutorial.com/posix/example/19828/remove-files-recursively--nftw--not-thread-safe- */
   
void myStat(struct stat Stat)
{
  printf("\nFile access: ");
  if (Stat.st_mode & R_OK)
    printf("read ");
  if (Stat.st_mode & W_OK)
    printf("write ");
  if (Stat.st_mode & X_OK)
    printf("execute");
  //printf("\nThis is: ");
  char buffer[300];

  printf("Ownership: UID=%ld   GID=%ld\n", (long)Stat.st_uid, (long)Stat.st_gid);
  printf("File size: %lld bytes\n", (long long)Stat.st_size);
  printf("Last file access:%s", ctime(&Stat.st_atime));
  strcpy(buffer, (const char *)ctime(&Stat.st_atime));
  printf("File changed time: %s\n", ctime(&Stat.st_ctime));
  printf("%s", buffer);
}

void search_file(char *where, char *file)
{
  struct stat Stat;
  DIR *dir;
  int found = 0;
  if (stat(file, &Stat) == 0)
  {
    if (NULL == (dir = opendir(where)))
    {
      printf("Eroare deschidere director %s .\n", where);
      exit(8);
    }
    struct dirent *director;
    while ((director = readdir(dir)))
    {
      if (strcmp(director->d_name, ".") && strcmp(director->d_name, ".."))
        if (strcmp(director->d_name, (const char *)file) == 0)
        {
          printf("\nFound!!\n");
          found = 1;
          myStat(Stat);
          break;
        }
    }
    if (!found)
      printf("Not found..\n");
    closedir(dir);
  }
  else
    printf("File '%s' does not exist.\n", file);
}
int exists(char *where, char *file)
{
  struct stat Stat;
  DIR *dir;
  int found = 0;
  if (stat(file, &Stat) == 0)
  {
    if (NULL == (dir = opendir(where)))
    {
      printf("Eroare deschidere director %s .\n", where);
      return 0;
    }
    struct dirent *director;
    while ((director = readdir(dir)))
    {
      if (strcmp(director->d_name, ".") && strcmp(director->d_name, ".."))
        if (strcmp(director->d_name, (const char *)file) == 0)
        {
          printf("\nFound!!\n");
          found = 1;
          return 1;
        }
    }
    if (!found)
      printf("Not found..\n");
    {
      closedir(dir);
      return 0;
    }
  }
  else
  {
    printf("File '%s' does not exist.\n", file);
    return 0;
  }
}

int main(int argc, char *argv[])
{

  int sock_desc;                            // descriptorul de socket
  struct sockaddr_in serverAddr;            // structura folosita pentru conectare
  char msg[100], id[50], pw[50], buff[100]; // mesajul trimis
  bzero(msg, 100);
  bzero(pw, 50);
  bzero(id, 50);
  /* cream socketul */
  if ((sock_desc = socket(AF_INET, SOCK_STREAM, 0)) == -1)
  {
    perror("Eroare la socket().\n");
    return errno;
  }

  /* umplem structura folosita pentru realizarea conexiunii cu serverul */
  /* familia socket-ului */
  serverAddr.sin_family = AF_INET;
  /* adresa IP a serverului */
  serverAddr.sin_addr.s_addr = inet_addr("127.0.0.1");
  /* portul de conectare */
  serverAddr.sin_port = htons(4444);

  /* ne conectam la server */
  if (connect(sock_desc, (struct sockaddr *)&serverAddr, sizeof(struct sockaddr)) == -1)
  {
    perror("[client]Eroare la connect().\n");
    return errno;
  }
  printf("\e[1;1H\e[2J");
  printf("Enter 'help' to get more info\n");
  while (1)
  {
    char cwd[PATH_MAX];
    char ccwd[PATH_MAX];

    if (getcwd(cwd, sizeof(cwd)) == NULL)
    {
      perror("getcwd() error");
      continue;
    }
    printf(yellow);

    printf(reset);

    fflush(stdout);

    // if (read(sock_desc, ccwd, sizeof(ccwd)) <= 0)
    // {
    //   printf("5");
    //   printf("failed to read ccwd or the server is down.\n");
    //   exit(1231);
    // }
    printf(reset);
    printf(blue);
    if (logged == 1)
    {

      printf(red);
      printf("CLIENT: ");
      printf(reset);
      printf(blue);
      printf("%s\n", cwd);
      printf(reset);
    }
    else
    {
      printf(red);
      printf("CLIENT: ");
      printf(reset);
      printf(blue);
      printf("%s\n", cwd);
      printf(reset);
    }
    printf(yellow);
    printf("\nCommand: ");
    printf(reset);
    printf(green);
    scanf("%s", msg);
    printf(reset);
    if (write(sock_desc, msg, sizeof(msg)) <= 0)
    {
      perror("Failed to write into socket\n");
      exit(3);
    }

    if (strcmp(msg, "help") == 0)
    {
      printf(yellow);
      printf("---General commands---\n");
      printf(reset);
      printf("\nlogin - log in so you can access server files.\nstat - Looks for a specific file in Server or local.\n");
      printf("logout - logging out of the server\n");
      printf("exit - close the connection\n");
      printf("stat [filename] - prints the details of filename\n");

      printf(yellow);
      printf("---Locally availavle commands (no login required)---\n");
      printf(reset);

      printf("mv [file] [destination] - moves file to a given destination\n");
      printf("ls - lists contents of the current working directory\n");
      printf("mkdir [directory_name] - creates a directory with a given name\n");
      // printf("rmdir [directory_name] - removes a director\n");

      printf(yellow);
      printf("---Server-sided commands (login required)---\n");
      printf(reset);

      printf("upload [local_file] - uploads a file on server\n");
      printf("download [server_file] - downloads a file from server\n");
      printf("sstat [server_file] - prints the details of given file from server\n");
      printf("smv [file] [destination] - moves file to a given destination \n");
      printf("sls - lists contents of the current working directory of the server\n");
      printf("smkdir [directory_name] - creates a directory with a given name\n");
      //printf("srmdir [directory_name] - removes a director\n");

      continue;
    }
    else if (strcmp(msg, "logout") == 0 && logged == 1)
    {
      logged = 0;
      printf("Loggin out...\n");
      continue;
    }
    else if (strcmp(msg, "logout") == 0 && logged == 0)
    {
      printf("You are already logged out...\n");
      logged = 0;
      continue;
    }
    if (strcmp(msg, "login") == 0 && logged == 0)
    {
      struct termios termInfo;
      int c;

      c = tcgetattr(0, &termInfo);

      if (c == -1)
      {
        perror("tcgetattr");
        exit(1);
      }
      if (termInfo.c_lflag & ECHO) // daca echo este deschis
      {
        printf("ID: ");
        fflush(stdout);

        scanf("%s", id);

        termInfo.c_lflag &= ~ECHO; //inchide echo
        tcsetattr(STDIN_FILENO, TCSANOW, &termInfo);

        printf("\nPassword: ");
        fflush(stdout);
        scanf("%s", pw);

        termInfo.c_lflag |= ECHO; // deschide echo
        tcsetattr(STDIN_FILENO, TCSANOW, &termInfo);
      }
      else
      {
        termInfo.c_lflag |= ECHO; // deschide echo
        tcsetattr(STDIN_FILENO, TCSANOW, &termInfo);
      }

      if (write(sock_desc, id, 50) <= 0)
        perror("Failed to write id\n");
      if (write(sock_desc, pw, 50) <= 0)
        perror("Failed to write pw\n");

      if (read(sock_desc, buff, 100) <= 0)
      {
        perror("Read error\n");
        exit(5);
      }
      if (buff[0] == '1')
        logged = 1;

      if (logged == 1)
      {
        printf(green);
        printf("\nLogged in!\n\n");
        printf(reset);
        fflush(stdout);
        continue;
      }
      else if (buff[0] == '2')
      {
        printf("This account is blacklisted.\n\n");
        fflush(stdout);
        continue;
      }
      else if (buff[0] == '3')
      {
        printf("You are already logged in.\n");
        fflush(stdout);
        continue;
      }
      else if (logged == 0)
      {
        printf("Wrong ID or Pw.Try again...\n\n");
        fflush(stdout);
        continue;
      }
    }
    else if (strcmp(msg, "login") == 0 && logged == 1)
    {
      printf("You are already logged in.\n");
      fflush(stdout);
      continue;
    }
    else if (strcmp(msg, "stat") == 0 )
    {
      char dir[200], fil[200];
      char cwd[PATH_MAX];
      if (getcwd(cwd, sizeof(cwd)) == NULL)
      {
        perror("getcwd() error");
        continue;
      }

      printf("File name (local): ");
      scanf("%s", fil);
      search_file(cwd, fil);
      continue;
    }
    else if (strcmp(msg, "sstat") == 0 && logged == 1)
    {
      char dir[200], fil[200];
      char buffer[1024];
      bzero(buffer, 1024);
      printf("File name (from server): ");
      scanf("%s", fil);

      if (write(sock_desc, fil, sizeof(fil)) <= 0)
      {
        perror("Failed to write filename. Try again\n");
        continue;
      }

      if (read(sock_desc, buffer, sizeof(buffer)) <= 0)
      {
        perror("Failed to read file stats");
        continue;
      }
      if (strcmp(buffer, "0"))
      {
        printf("%s\n", buffer);
        continue;
      }
      else
      {
        printf("the file doesnt exist\n");
        continue;
      }

      continue;
    }

    else if (strcmp(msg, "smv") == 0 && logged == 1)
    {
      char file[1024], location[1024], resp[10], ch;
      //printf("File: ");
      scanf("%s", file);
      fflush(stdin);
      //printf("Location: ");
      scanf("%s", location);

      if (write(sock_desc, file, sizeof(file)) <= 0)
      {
        printf("Failed to write file\n");
        continue;
      }
      if (write(sock_desc, location, sizeof(location)) <= 0)
      {
        printf("Failed to write location\n");
        continue;
      }
    }
    else if (strcmp(msg, "rm") == 0)
    {
      char file[1024], message[100];
      scanf("%s", file);
      char cwd[PATH_MAX];
      if (getcwd(cwd, sizeof(cwd)) == NULL)
      {
        perror("getcwd() error");
        continue;
      }
      FILE *f = fopen(file, "r");
      if (!f)
      {
        printf("File doesnt exist\n");
        continue;
      }
      else
      {
        strcat(cwd, "/");
        strcat(cwd, file);
        if (isDirectory(cwd) == 1)
        {
          printf("rm only deletes files!");
          continue;
        }
        remove(cwd);
        printf("File removed successfully\n");
      }

      //printf("%s\n", message);
      continue;
    }
    else if (strcmp(msg, "srm") == 0)
    {
      char file[1024], message[100];
      scanf("%s", file);

      if (write(sock_desc, file, sizeof(file)) <= 0)
      {
        printf("Failed to write file..\n");
        continue;
      }

      if (read(sock_desc, message, sizeof(message)) <= 0)
      {
        printf("Failed to read message_back\n");
        continue;
      }

      printf("%s\n", message);
      continue;
    }

    /*else if (strcmp(msg, "srmdir") == 0 && logged == 1)
    {
      char cwd[PATH_MAX], nume_director[100], path[200], mesaj[100];
      if (getcwd(cwd, sizeof(cwd)) == NULL)
      {
        perror("getcwd() error");
        continue;
      }
      printf("Directory: ");
      scanf("%s", nume_director);

      if (write(sock_desc, nume_director, sizeof(nume_director)) <= 0)
      {
        printf("Failed to write nume_director.\n");
        continue;
      }

      if (read(sock_desc, mesaj, sizeof(mesaj)) <= 0)
      {
        printf("Failed to read mesaj.\n");
        continue;
      }
      printf("%s\n", mesaj);
      continue;
    }

    else if (strcmp(msg, "rmdir") == 0)
    {
      char cwd[PATH_MAX], nume_director[100], path[200];
      if (getcwd(cwd, sizeof(cwd)) == NULL)
      {
        perror("getcwd() error");
        continue;
      }

      scanf("%s", nume_director);

      if (!exists(cwd, nume_director))
      {
        printf("Nu exista directorul.\n");
        continue;
      }
      else
      {
        strcpy(path, cwd);
        strcat(path, "/");
        strcat(path, nume_director);
        rmrf(path);
        printf("Directory removed successfully\n");
      }
      continue;
    }*/

    //MKDIR
    else if (strcmp(msg, "mkdir") == 0)
    {
      char name[100], path[100];
      char cwd[PATH_MAX];
      if (getcwd(cwd, sizeof(cwd)) == NULL)
      {
        perror("getcwd() error");
        continue;
      }
      scanf("%s", name);
      if (makeDirectory(cwd, name) == 0)
        printf("Couldn't create directory\n");
      else
        printf("%s was successfully created!\n", name);

      continue;
    }

    //SMKDIR
    else if (strcmp(msg, "smkdir") == 0 && logged == 1)
    {
      char name[100], recieve_response[100];
      scanf("%s", name);

      if (write(sock_desc, name, sizeof(name)) <= 0)
      {
        printf("failed to write smkdir name\n");
        continue;
      }

      if (read(sock_desc, recieve_response, sizeof(recieve_response)) <= 0)
      {
        printf("failed to read recieve_response");
        continue;
      }
      else
      {
        printf("%s\n", recieve_response);
        continue;
      }

      continue;
    }

    else if (strcmp(msg, "download") == 0 && logged == 1)
    {
      char cwd[PATH_MAX];
      if (getcwd(cwd, sizeof(cwd)) == NULL)
      {
        perror("getcwd() error");
        continue;
      }
      ssize_t n, total = 0, filesize;
      char error[1];
      char file[1024];
      bzero(error, 1);
      scanf("%s", file);

      if (write(sock_desc, file, sizeof(file)) <= 0)
      {
        perror("error at sending file name");
        continue;
      }
      FILE *f = fopen(file, "wb");
      if (!f)
      {
        perror("failed to create file\n");
        exit(55);
        continue;
      }
      if (read(sock_desc, error, sizeof(error)) <= 0)
      {
        perror("error writing back");
        continue;
      }
      if (error[0] == '0')
      {
        perror("File doesnt exist.");

        fclose(f);
        //remove(file);
        continue;
      }

      if (read(sock_desc, &filesize, sizeof(filesize)) <= 0)
      {
        printf("Failed to read actual filesize\n");
        continue;
      }

      char buff[MAX_LINE] = {0};
      while (1)
      {
        // sleep(3);
        if ((n = recv(sock_desc, buff, MAX_LINE, 0)) <= 0)
          break;
        total += n;
        if (n == -1)
        {
          perror("Receive File Error");
          break;
        }
        if (fwrite(buff, sizeof(char), n, f) != n)
        {
          perror("Write File Error");
          break;
        }
        if (n < MAX_LINE)
          break;
        memset(buff, 0, MAX_LINE);
      }
      fclose(f);
      if (total == filesize)
        printf("Download successful!\n");
      else
        printf("Download failed.\n");
      continue;
    }

    else if (strcmp(msg, "upload") == 0 && logged == 1)
    {
      char file[1024], error[] = "File doesnt exist";
      char sendline[MAX_LINE] = {0};
      ssize_t total = 0;
      scanf("%s", file);
      FILE *f = fopen(file, "rb");
      ssize_t n;

      if (!f)
      {
        perror("failed to locate file");
      }
      if (write(sock_desc, file, sizeof(file)) <= 0)
      {
        perror("error at sending file name");
        continue;
      }

      while ((n = fread(sendline, sizeof(char), MAX_LINE, f)) > 0)
      {
        total += n;
        if (n != MAX_LINE && ferror(f))
        {
          perror("Read File Error");
          break;
        }
        if (send(sock_desc, sendline, n, MSG_NOSIGNAL) == -1)
        {
          switch (errno)
          {
          case EPIPE:
            printf("Connection closed.");
            break;
          }
          perror("Can't send file");
          break;
        }
        memset(sendline, 0, MAX_LINE);
      }
      printf("Sent Success, NumBytes = %ld\n", total);
      fclose(f);
      continue;
    }

    else if (strcmp(msg, "mv") == 0)
    {
      char file[1024], location[1024], resp[10], ch;
      //printf("File: ");
      scanf("%s", file);
      fflush(stdin);

      int f = open(file, O_RDONLY);
      if (!f)
      {
        perror("failed to locate file");
        continue;
      }

      //printf("Location: ");
      scanf("%s", location);

      if (logged == 0 && strstr(location, "SERVER"))
      {
        perror("You need to be logged in to access server\n");
        continue;
      }
      if (logged == 1 && strstr(location, "CLIENT"))
      {
        perror("Cannot move files. Use upload/download\n");
        continue;
      }
      DIR *dir;
      struct dirent *ent;
      struct stat sb;
      char cwd[PATH_MAX];
      char dest[PATH_MAX];

      if (getcwd(cwd, sizeof(cwd)) == NULL)
      {
        perror("getcwd() error");
        continue;
      }

      if ((dir = opendir(location)) != NULL)
      {
        while ((ent = readdir(dir)) != NULL)
        {
          if (strcmp(ent->d_name, file) == 0)
          {
            printf("The file already exists in the specified location.\nWould you like to replace it? [y/n] ");
            scanf("%s", resp);
            if (resp[0] == 'y')
            {
              if (mv(file, location) < 0)
                continue;
              else
                break;
            }
            else
              break;
          }
          else
          {
            if (mv(file, location) < 0)
              continue;
            else
              break;
          }
        }
        printf("\n");
        closedir(dir);
        continue;
      }
      else
      {
        perror("could not open location");
        continue;
      }
      continue;
    }

    else if (strcmp(msg, "cd") == 0)
    {
      char buffer[PATH_MAX];
      char cwd[PATH_MAX];
      if (getcwd(cwd, sizeof(cwd)) == NULL)
      {
        perror("getcwd() error");
        continue;
      }
      int l;
      l = strlen(cwd);
      scanf("%s", buffer);
      chdir(buffer);

      continue;
    }
    else if (strcmp(msg, "scd") == 0 && logged == 1)
    {
      char buffer[PATH_MAX];
      char cwd[PATH_MAX];
      if (getcwd(cwd, sizeof(cwd)) == NULL)
      {
        perror("getcwd() error");
        continue;
      }
      scanf("%s", buffer);

      if (write(sock_desc, buffer, sizeof(buffer)) <= 0)
      {
        printf("write error scd\n");
        continue;
      }

      //chdir(buffer);

      continue;
    }

    else if (strcmp(msg, "sls") == 0 && logged == 1)
    {
      char send[2048], cwd[PATH_MAX], scwd[PATH_MAX];
      bzero(send, 2048);
      if (read(sock_desc, scwd, sizeof(scwd)) <= 0)
      {
        printf("Failed to read scwd\n");
        continue;
      }
      printf(red);
      printf("SERVER: ");
      printf(reset);
      printf(blue);
      printf("%s\n", scwd);
      printf(reset);
      
      if (getcwd(cwd, sizeof(cwd)) == NULL)
      {
        perror("getcwd() error");
        continue;
      }

      if (read(sock_desc, send, sizeof(send)) <= 0)
      {
        perror("Failed to read ls");
        continue;
      }
      char *token;
      token = strtok(send, ";");
      while (token != NULL)
      {
        if (token[0] == '&')
          printf("\033[0;34m");
        else if (token[0] == '^')
          printf("\033[0;32m");
        else if (token[0] == '#')
          printf("\033[0;36m");
        else
          printf("\033[0m");

        printf("%s  ", (token + 1));
        printf("\033[0m");
        token = strtok(NULL, ";");
      }
      printf("\n");
      continue;
    }
    else if (strcmp(msg, "ls") == 0)
    {
      DIR *dir;
      struct dirent *ent;
      struct stat sb;
      char cwd[PATH_MAX];
      if (getcwd(cwd, sizeof(cwd)) == NULL)
      {
        perror("getcwd() error");
        continue;
      }

      if ((dir = opendir(cwd)) != NULL)
      {
        while ((ent = readdir(dir)) != NULL)
        {
          if (strcmp(ent->d_name, ".") && strcmp(ent->d_name, ".."))
            if (isDirectory(ent->d_name))
            {
              printf("\033[0;34m%s   \033[0m", ent->d_name);
            }
            else if (isExec(ent->d_name))
            {
              printf("\033[0;32m%s   \033[0m", ent->d_name);
            }
            else if (strstr(ent->d_name, ".jpg"))
            {
              printf("\033[0;36m%s   \033[0m", ent->d_name);
            }
            else
            {
              printf("\033[0m%s   ", ent->d_name);
            }
        }
        printf("\n");
        closedir(dir);
        continue;
      }
      else
      {
        perror("could not open directory");
        continue;
      }
    }

    else if (strcmp(msg, "exit") == 0)
    {
      printf("Exiting...\n");
      logged = 0;
      close(sock_desc);
      exit(7);
    }
    else
    {
      printf("Invalid command.\n");
      continue;
    }

  } //while(1)
  close(sock_desc);
} // main
