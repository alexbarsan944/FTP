#include <sys/types.h>
#include <sys/wait.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <errno.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/stat.h>
#include <dirent.h>
#include <time.h>
#include <fcntl.h>


#define red "\033[0;31m"
#define green "\033[0;32m"
#define yellow "\033[0;33m"
#define blue "\033[0;34m"
#define reset "\033[0m"
#define PATH_MAX 4096
#define MAX_LINE 4096

#define PORT 4444

/* codul de eroare returnat de anumite apeluri */
extern int errno;
int logged;
char loggedUsers[2048];

size_t getFilesize(const char *filename)
{
  struct stat st;
  if (stat(filename, &st) != 0)
  {
    return 0;
  }
  return st.st_size;
}



int exists(char *where, char *file)
{
  struct stat Stat;
  DIR *dir;
  int found = 0;
  if (stat(file, &Stat) == 0)
  {
    if (NULL == (dir = opendir(where)))
    {
      printf("Eroare deschidere director %s .\n", where);
      return 0;
    }
    struct dirent *director;
    while ((director = readdir(dir)))
    {
      if (strcmp(director->d_name, ".") && strcmp(director->d_name, ".."))
        if (strcmp(director->d_name, (const char *)file) == 0)
        {
          printf("\nFound!!\n");
          found = 1;
          return 1;
        }
    }
    if (!found)
      printf("Not found..\n");
    {
      closedir(dir);
      return 0;
    }
  }
  else
  {
    printf("File '%s' does not exist.\n", file);
    return 0;
  }
}


void dec()
{
  char fname[50], ch;
  FILE *fps, *fpt;
  strcpy(fname, "login.txt");
  fps = fopen(fname, "r");
  if (fps == NULL)
  {
    printf("Error in opening file..!!");
    exit(1);
  }
  fpt = fopen("temp.txt", "w");
  if (fpt == NULL)
  {
    printf("Error in creating temp.txt file..!!");
    fclose(fps);
    exit(2);
  }
  while (1)
  {
    ch = fgetc(fps);
    if (ch == EOF)
    {
      break;
    }
    else
    {
      ch = ch - 100;
      fputc(ch, fpt);
    }
  }
  fclose(fps);
  fclose(fpt);
  fps = fopen(fname, "w");
  if (fps == NULL)
  {
    printf("Error in opening source file..!!");
    exit(3);
  }
  fpt = fopen("temp.txt", "r");
  if (fpt == NULL)
  {
    printf("Error in opening temp.txt file...!!");
    fclose(fps);
    exit(4);
  }
  while (1)
  {
    ch = fgetc(fpt);
    if (ch == EOF)
    {
      break;
    }
    else
    {
      fputc(ch, fps);
    }
  }

  fclose(fps);
  fclose(fpt);
}
int mv(char file[1024], char location[1024])
{
  char ch;
  FILE *f = fopen(file, "rb");
  if (f == NULL)
  {
    printf("Error in opening file..!!");
    return 0;
  }

  char cwd[1024];
  if (getcwd(cwd, sizeof(cwd)) == NULL)
  {
    perror("getcwd() error");
    return -1;
  }

  char dest[1024];
  if (getcwd(dest, sizeof(dest)) == NULL)
  {
    perror("getcwd() error");
    return -2;
  }
  strcat(dest, "/");
  strcat(dest, location);
  chdir(dest);
  printf("%s --mv function \n", dest);
  FILE *g = fopen(file, "w");

  if (g == NULL)
  {
    printf("couldnt open file\n");
    return -3;
  }
  char line[MAX_LINE] = {0};
  ssize_t n, total = 0;
  while ((n = fread(line, sizeof(char), MAX_LINE, f)) > 0)
  {
    total += n;
    if (n != MAX_LINE && ferror(f))
    {
      perror("Read File Error");
      break;
    }
    if (fwrite(line, sizeof(char), n, g) != n)
    {
      perror("Write File Error");
      break;
    }
    if (n < MAX_LINE)
      break;
    memset(line, 0, MAX_LINE);
  }

  chdir(cwd);
  remove(file);

  fclose(f);
  fclose(g);
  return 1;
}
void enc()
{
  char fname[50], ch;
  FILE *fps, *fpt;
  strcpy(fname, "login.txt");
  fps = fopen(fname, "r");
  if (fps == NULL)
  {
    printf("Error in opening file..!!");
    exit(1);
  }
  fpt = fopen("temp.txt", "w");
  if (fpt == NULL)
  {
    printf("Error in creating temp.txt file..!!");
    fclose(fps);
    exit(2);
  }
  while (1)
  {
    ch = fgetc(fps);
    if (ch == EOF)
    {
      break;
    }
    else
    {
      ch = ch + 100;
      fputc(ch, fpt);
    }
  }
  fclose(fps);
  fclose(fpt);
  fps = fopen(fname, "w");
  if (fps == NULL)
  {
    printf("Error in opening source file..!!");
    exit(3);
  }
  fpt = fopen("temp.txt", "r");
  if (fpt == NULL)
  {
    printf("Error in opening temp.txt file...!!");
    fclose(fps);
    exit(4);
  }
  while (1)
  {
    ch = fgetc(fpt);
    if (ch == EOF)
    {
      break;
    }
    else
    {
      fputc(ch, fps);
    }
  }

  fclose(fps);
  fclose(fpt);
}

int isDirectory(const char *path)
{
  struct stat statbuf;
  if (stat(path, &statbuf) != 0)
    return 0;
  return S_ISDIR(statbuf.st_mode);
}
int isExec(const char *path)
{
  struct stat sb;
  if (stat(path, &sb) != 0)
    return 0;
  return (sb.st_mode & S_IXUSR);
}

int makeDirectory(char *where, char *name)
{
  if (!isDirectory(where))
  {
    printf("This already exists.\n");
    fflush(stdout);
  }

  if (mkdir(name, 0777) == -1)
  {
    printf("%s\n", "Eroare la crearea directorului");
    return 0;
  }
  return 1;
}

const char *myStat(struct stat Stat)
{
  char b1[100], b2[100], b3[100];
  bzero(b1, 100);
  bzero(b2, 100);
  bzero(b3, 100);

  strcpy(b1, "File access: ");
  if (Stat.st_mode & R_OK)
    strcat(b1, "read ");
  if (Stat.st_mode & W_OK)
    strcat(b1, "write ");
  if (Stat.st_mode & X_OK)
    strcat(b1, "execute");
  strcat(b1, "\n");

  strcpy(b2, "Last file access: ");
  strcat(b2, (const char *)ctime(&Stat.st_atime));
  strcat(b2, "\n");

  strcat(b1, b2);

  strcpy(b3, "File changed time: ");
  strcat(b3, (const char *)ctime(&Stat.st_ctime));
  strcat(b3, "\n");

  strcat(b1, b3);
}

int count_lines(char *name)
{
  FILE *f = fopen(name, "r");
  int lines_number = 0;
  for (int i = getc(f); i != EOF; i = getc(f))
    if (i == '\n')
      lines_number++;
  fclose(f);
  return lines_number + 1;
}



int verifyLogin(char id[], char pw[])
{
  FILE *f, *b;
  int ok = 0;
  f = fopen("login.txt", "r");
  b = fopen("blacklist.txt", "r");
  if (f < 0)
    perror("error opening file");
  char temp_id[100];
  char temp_pw[100];
  bzero(temp_id, 100);
  bzero(temp_pw, 100);
  int f_lines_number = count_lines("login.txt");
  int b_lines_number = count_lines("blacklist.txt");
  for (int j = 0; j < b_lines_number; j++)
  {
    fscanf(b, "%s %s", temp_id, temp_pw);
    if (strcmp(id, temp_id) == 0 && strcmp(pw, temp_pw) == 0)
    {
      fclose(b);
      enc();
      return -1;
    }
  }
  bzero(temp_id, 100);
  bzero(temp_pw, 100);
  for (int i = 0; i < f_lines_number; i++)
  {
    fscanf(f, "%s %s", temp_id, temp_pw);

    if (strcmp(id, temp_id) == 0 && strcmp(pw, temp_pw) == 0)
    {
      fclose(f);
      enc();
      return 1;
    }
  }
  fclose(f);
  enc();

  return 0;
}

void handle()
{
  while (waitpid(-1, NULL, WNOHANG) > 0)
    ;
  // If pid is -1, waitpid() waits for any child process to end.
  //status_ptr pointer is null, waitpid() ignores the child's return status
  //WNOHANG checks child processes without causing the caller to be suspended
  //functia returneaza valoarea procesului (copil)
}

int main()
{
  struct sockaddr_in serverAddr; // structura folosita de server
  struct sockaddr_in clientAddr;
  bzero(&serverAddr, sizeof(serverAddr));
  bzero(&clientAddr, sizeof(clientAddr));
  char msgRecieved[100];   //mesajul primit de la client
  char msgSent[100] = " "; //mesaj de raspuns pentru client
  int sock_desc;           //descriptorul de socket
  bzero(msgSent, 100);
  bzero(msgRecieved, 100);
  char id[50], pw[50];

  /* crearea unui socket */
  if ((sock_desc = socket(AF_INET, SOCK_STREAM, 0)) == -1)
  {
    perror("[server]Eroare la socket().\n");
    return errno;
  }

  /* pregatirea structurilor de date */

  /* umplem structura folosita de server */
  /* stabilirea familiei de socket-uri */
  serverAddr.sin_family = AF_INET;
  /* acceptam orice adresa */
  serverAddr.sin_addr.s_addr = htonl(INADDR_ANY);
  /* utilizam un port utilizator */
  serverAddr.sin_port = htons(PORT);

  int reuse = 1;
  if (setsockopt(sock_desc, SOL_SOCKET, SO_REUSEADDR, (const char *)&reuse, sizeof(reuse)) < 0)
    perror("setsockopt(SO_REUSEADDR) failed");


  /* atasam socketul */
  if (bind(sock_desc, (struct sockaddr *)&serverAddr, sizeof(struct sockaddr)) == -1)
  {
    perror("[server]Eroare la bind().\n");
    return errno;
  }

  /* punem serverul sa asculte daca vin clienti sa se conecteze */
  if (listen(sock_desc, 5) == -1)
  {
    perror("[server]Eroare la listen().\n");
    return errno;
  }

  /* servim in mod iterativ clientii... */
  while (1)
  {
    int clientFD;
    int length = sizeof(clientAddr);

    printf("[server]Waiting at port %d...\n", PORT);
    fflush(stdout);

    /* acceptam un client (stare blocanta pina la realizarea conexiunii) */
    clientFD = accept(sock_desc, (struct sockaddr *)&clientAddr, &length);
    pid_t PID;
    PID = fork();
    if (PID) //PARINTE
    {
      signal(SIGCHLD, handle);
    }
    else
    {
      /* eroare la acceptarea conexiunii de la un client */
      if (clientFD < 0)
      {
        perror("accept() error.\n");
        continue;
      }

      fflush(stdout);
      while (1) // Asteptam mesaje incontinuu
      {

        printf("Waiting for command...\n");
        fflush(stdout);
        if (read(clientFD, msgRecieved, 100) <= 0)
        {
          if (logged == 1)
          {
            printf("\nClient '%s'(%s) disconnected \n", id, inet_ntoa(clientAddr.sin_addr));
            fflush(stdout);
          }
          else
          {
            printf("\nClient (%s) disconnected \n", inet_ntoa(clientAddr.sin_addr));
            fflush(stdout);
          }
          logged = 0;
          close(clientFD); /* inchidem conexiunea cu clientul */
          break;
          continue; /* continuam sa ascultam */
        }

        printf("Command %s recieved \n", msgRecieved);
        fflush(stdout);
        if (strcmp(msgRecieved, "help") == 0)
          continue;
        else if (strcmp(msgRecieved, "logout") == 0 && logged == 1)
        {
          logged = 0;
          printf("Client logged out");
          fflush(stdout);
          continue;
        }
        else if (strcmp(msgRecieved, "logout") == 0 && logged == 0)
        {
          logged = 0;
          continue;
        }

        else if (strcmp(msgRecieved, "login") == 0 && logged == 0)
        {
          bzero(pw, 50);
          bzero(id, 50);

          dec();

          if (read(clientFD, id, 50) <= 0)
          {
            perror("Failed to read id\n");
          }
          if (read(clientFD, pw, 50) <= 0)
          {
            perror("Failed to read pw\n");
          }
          int loginVar;
          loginVar = verifyLogin(id, pw);

          if (loginVar == 1 && logged == 0)
          {
            logged = 1;

            printf("\nClient '%s' logged in (%s) \n", id, inet_ntoa(clientAddr.sin_addr));
            fflush(stdout);

            if (write(clientFD, "1", 1) <= 0)
            {
              perror("Server- error ar writing1");
            }
          }

          else if (loginVar == -1)
          {
            if (write(clientFD, "2", 1) <= 0)
            {
              perror("Server- error ar writing1");
            }
            printf("Blacklisted account\n");
            fflush(stdout);
          }
          else
          {
            printf("%s - %s\n", id, pw);
            fflush(stdout);
            if (write(clientFD, "0", 1) <= 0)
            {
              perror("Server- error ar writing1");
            }
            printf("Wrong ID or PW...\n");
            fflush(stdout);
            continue;
          }
        }

        else if (strcmp(msgRecieved, "login") == 0 && logged == 1)
        {
          printf("\nClient '%s' tried to login again (%s) \n", id, inet_ntoa(clientAddr.sin_addr));
          fflush(stdout);
          continue;
        }

        else if (strcmp(msgRecieved, "stat") == 0 && logged == 0)
        {
          printf("stat (client)...\n");
          fflush(stdout);
          continue;
        }
        else if (strcmp(msgRecieved, "download") == 0 && logged == 1)
        {

          char file[1024], error[] = "File doesnt exist";
          char sendline[MAX_LINE] = {0};
          ssize_t n, total = 0, filesize = -1;

          if (read(clientFD, file, sizeof(file)) <= 0)
          {
            perror("error at reading file name");
            continue;
          }
          FILE *f = fopen(file, "rb");
          if (!f)
          {
            perror("cannot open file\n");

            if (write(clientFD, "0", 1) <= 0)
            {
              perror("error writing back");
              continue;
            }
            continue;
          }
          else
          {
            if (write(clientFD, "1", 1) <= 0)
            {
              perror("error writing back2");
              continue;
            }
          }
          filesize = getFilesize(file);

          if (write(clientFD, &filesize, sizeof(filesize)) <= 0)
          {
            printf("failed to write actual filesize\n");
            continue;
          }
          //printf("%s\n", file);

          while ((n = fread(sendline, sizeof(char), MAX_LINE, f)) > 0)
          {
            // sleep(3);
            total += n;
            if (n != MAX_LINE && ferror(f))
            {
              printf("Read File Error");
              break;
            }
            if (send(clientFD, sendline, n, MSG_NOSIGNAL) < 0)
            {
              switch (errno)
              {
              case EPIPE:
                printf("Connection closed.");
                break;
              }
              perror("Can't send file");
              break;
            }
            else
              memset(sendline, 0, MAX_LINE);
          }
          fclose(f);
          continue;
        }
        else if (strcmp(msgRecieved, "smv") == 0 && logged == 1)
        {
          char file[1024], location[1024], resp[10], ch;

          if (read(clientFD, file, sizeof(file)) <= 0)
          {
            printf("Failed to read file\n");
            continue;
          }
          if (read(clientFD, location, sizeof(location)) <= 0)
          {
            printf("Failed to read location\n");
            continue;
          }
          printf("%s - file \n %s location\n", file, location);
          DIR *dir;
          struct dirent *ent;
          struct stat sb;
          char cwd[PATH_MAX];
          char dest[PATH_MAX];

          if (getcwd(cwd, sizeof(cwd)) == NULL)
          {
            perror("getcwd() error");
            continue;
          }
          printf("%s - file \n %s location\n", file, location);

          if ((dir = opendir(location)) != NULL)
          {
            while ((ent = readdir(dir)) != NULL)
            {
              if (mv(file, location) < 0)
                continue;
              else
                break;
            }
            printf("\n");
            closedir(dir);
            continue;
          }
          else
          {
            perror("could not open location");
            continue;
          }
          continue;
        }
        else if (strcmp(msgRecieved, "smkdir") == 0 && logged == 1)
        {
          char name[100], response[100];
          char cwd[PATH_MAX];
          if (getcwd(cwd, sizeof(cwd)) == NULL)
          {
            perror("getcwd() error");
            continue;
          }

          if (read(clientFD, name, sizeof(name)) <= 0)
          {
            printf("failed to read name smkdir");
            continue;
          }

          if (makeDirectory(cwd, name) == 0)
          {
            strcpy(response, "Couldn't create directory");
            if (write(clientFD, response, sizeof(response)) <= 0)
            {
              printf("failed to write response smkdir");
              continue;
            }
          }
          else
          {
            strcpy(response, "Directory successfully created!");
            if (write(clientFD, response, sizeof(response)) <= 0)
            {
              printf("failed to write response(2) smkdir");
              continue;
            }
          }

          continue;
        }
         /*else if (strcmp(msgRecieved, "srmdir") == 0 && logged == 1)
        {
          char cwd[PATH_MAX], nume_director[100], path[200], mesaj[100];
          if (getcwd(cwd, sizeof(cwd)) == NULL)
          {
            perror("getcwd() error");
            continue;
          }
          if (read(clientFD, nume_director, sizeof(nume_director)) <= 0)
          {
            printf("Failed to read nume_director.\n");
            continue;
          }
          if (!exists(cwd, nume_director))
          {
            strcpy(mesaj, "No such directory");
            if (write(clientFD, mesaj, sizeof(mesaj)) <= 0)
            {
              printf("Failed to write mesaj.\n");
              continue;
            }
            continue;
          }
          else
          {
            strcpy(path, cwd);
            strcat(path, "/");
            strcat(path, nume_director);
            rmrf(path);

            strcpy(mesaj, "Directory removed successfully");
            if (write(clientFD, mesaj, sizeof(mesaj)) <= 0)
            {
              printf("Failed to write mesaj.\n");
              continue;
            }
          }
          continue;
        }*/
        else if (strcmp(msgRecieved, "srm") == 0 && logged == 1)
        {
          char file[1024], message_back[] = "File removed successfully!", msgg[] = "File doesnt exist";
          if (read(clientFD, file, sizeof(file)) <= 0)
          {
            printf("Failed to read file..\n");
            continue;
          }
          char cwd[PATH_MAX];
          if (getcwd(cwd, sizeof(cwd)) == NULL)
          {
            perror("getcwd() error");
            continue;
          }
          printf("%s--cwd\n", cwd);
          FILE *f = fopen(file, "r");
          if (!f)
          {
            printf("File doesnt exist\n");
            if (write(clientFD, msgg, sizeof(msgg)) <= 0)
            {
              printf("Failed to write msgg\n");
              continue;
            }
            continue;
          }
          else
          {
            strcat(cwd, "/");
            strcat(cwd, file);
            remove(cwd);

            if (write(clientFD, message_back, sizeof(message_back)) <= 0)
            {
              printf("Failed to write message_back\n");
              continue;
            }

            if (isDirectory(cwd) == 1)
            {
              strcpy(message_back, "srm only deletes files!");
              if (write(clientFD, message_back, sizeof(message_back)) <= 0)
              {
                printf("Failed to write message_back\n");
                continue;
              }
            }
          }
          continue;
        }
        else if (strcmp(msgRecieved, "upload") == 0 && logged == 1)
        {
          ssize_t total = 0;
          char error[100];
          char file[1024];

          if (read(clientFD, file, sizeof(file)) <= 0)
          {
            perror("error at reading file name");
            continue;
          }
          FILE *f = fopen(file, "wb");
          if (!f)
          {
            perror("cannot open file\n");
            continue;
          }
          ssize_t n;
          char buff[MAX_LINE] = {0};
          while (1)
          {
            if ((n = recv(clientFD, buff, MAX_LINE, 0)) <= 0)
              break;
            total += n;
            if (n == -1)
            {
              perror("Receive File Error");
              break;
            }
            fflush(stdout);
            if (fwrite(buff, sizeof(char), n, f) != n)
            {
              perror("Write File Error");
              break;
            }
            if (n < MAX_LINE)
              break;
            memset(buff, 0, MAX_LINE);
          }
          printf("Sent Success, NumBytes = %ld\n", total);
          fflush(stdout);
          fclose(f);
          continue;
        }
        else if (strcmp(msgRecieved, "scd") == 0 && logged == 1)
        {
          char cwd[PATH_MAX], buffer[PATH_MAX];
          if (getcwd(cwd, sizeof(cwd)) == NULL)
          {
            perror("getcwd() error");
            continue;
          }

          if (read(clientFD, buffer, sizeof(buffer)) <= 0)
          {
            printf("read error scd\n");
            continue;
          }

          chdir(buffer);
          continue;
        }
        else if (strcmp(msgRecieved, "sls") == 0 && logged == 1)
        {
          DIR *dir;
          struct dirent *ent;
          char cwd[PATH_MAX];
          struct stat sb;
          char color[100], files[1024], send[2048];
          bzero(send, 2048);
          if (getcwd(cwd, sizeof(cwd)) == NULL)
          {
            perror("getcwd() error");
            continue;
          }
          if(write(clientFD, cwd, sizeof(cwd))<=0)
          {
            printf("faield to write cwd\n");
            continue;
          }
          printf("%s", cwd);
          fflush(stdout);
          if ((dir = opendir(cwd)) != NULL)
          {
            while ((ent = readdir(dir)) != NULL)
            {
              if (strcmp(ent->d_name, ".") && strcmp(ent->d_name, ".."))
                if (isDirectory(ent->d_name))
                {
                  bzero(color, 100);
                  bzero(files, 1024);

                  strcpy(color, ";&"); //blue \033[0;34m
                  strcpy(files, (const char *)(ent->d_name));
                  strcat(color, files);
                  strcat(send, color);
                  //printf("%s\n", send);

                  fflush(stdout);
                }
                else if (isExec(ent->d_name))
                {
                  bzero(color, 100);
                  bzero(files, 1024);

                  strcpy(color, ";^"); //green \033[0m;32m
                  strcpy(files, (const char *)(ent->d_name));
                  strcat(color, files);
                  strcat(send, color);
                  //printf("%s\n", send);

                  fflush(stdout);
                }
                else if (strstr(ent->d_name, ".jpg"))
                {
                  bzero(color, 100);
                  bzero(files, 1024);

                  strcpy(color, ";#"); // cyan
                  strcpy(files, (const char *)(ent->d_name));
                  strcat(color, files);
                  strcat(send, color);
                }
                else
                {
                  bzero(color, 100);
                  bzero(files, 1024);

                  strcpy(color, ";$"); // reset \033[0m;
                  strcpy(files, (const char *)(ent->d_name));
                  strcat(color, files);
                  strcat(send, color);
                  //printf("%s\n", send);
                }
            }
            printf("\n");
            fflush(stdout);
            if (write(clientFD, send, sizeof(send)) <= 0)
            {
              perror("Failed to write ls");
              continue;
            }
            closedir(dir);
            continue;
          }
          else
          {
            perror("could not open directory");
            continue;
          }
        }

        else if (strcmp(msgRecieved, "sstat") == 0 && logged == 1)
        {
          char fil[200], directory[100];
          char *command;
          bzero(fil, 200);
          char cwd[PATH_MAX];
          if (getcwd(cwd, sizeof(cwd)) == NULL)
          {
            perror("getcwd() error");
            continue;
          }
          printf("File name (from server): ");
          fflush(stdout);

          if (read(clientFD, fil, sizeof(fil)) <= 0)
          {
            perror("Failed to write filename. Try again\n");
            continue;
          }

          struct stat Stat;
          DIR *dir;
          int found = 0;

          if (stat(fil, &Stat) == 0)
          {
            if (NULL == (dir = opendir(cwd)))
            {
              printf("Eroare deschidere director %s .\n", cwd);
              fflush(stdout);
            }
            struct dirent *director;
            while ((director = readdir(dir)))
            {
              if (strcmp(director->d_name, ".") && strcmp(director->d_name, ".."))
                if (strcmp(director->d_name, (const char *)fil) == 0)
                {
                  printf("\nFound!!\n");
                  fflush(stdout);
                  found = 1;
                  {
                    char b1[100], b2[100], b3[100];
                    bzero(b1, 100);
                    bzero(b2, 100);
                    bzero(b3, 100);

                    strcpy(b1, "\nFile access: ");
                    if (Stat.st_mode & R_OK)
                      strcat(b1, "read ");
                    if (Stat.st_mode & W_OK)
                      strcat(b1, "write ");
                    if (Stat.st_mode & X_OK)
                      strcat(b1, "execute");
                    strcat(b1, "\n");

                    strcpy(b2, "Last file access: ");
                    strcat(b2, (const char *)ctime(&Stat.st_atime));
                    strcat(b1, b2);

                    strcpy(b3, "File changed time: ");
                    strcat(b3, (const char *)ctime(&Stat.st_ctime));

                    strcat(b1, b3);

                    printf("\n\n%s\n\n", b1);
                    if (write(clientFD, b1, sizeof(b1)) <= 0)
                    {
                      perror("Failed to write stats.\n");
                      continue;
                    }
                  }
                }
            }
            if (!found)
            {
              printf("Not found..\n");
              fflush(stdout);
            }
            closedir(dir);
          }
          else
          {
            if (write(clientFD, "0", 1) <= 0)
            {
              perror("Failed to write signal.\n");
              continue;
            }
            printf("File '%s' does not exist.\n", fil);
            fflush(stdout);
            continue;
          }
        } // end stat

        else if (strcmp(msgRecieved, "cd") == 0)
        {
          printf("Changing directory..\n");
          fflush(stdout);
        }


      } //while(1) - read/write
      close(clientFD);

    } /*end fork()*/
  }   /* while */
} /* main */