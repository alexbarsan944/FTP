#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <errno.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/stat.h>
#include <dirent.h>
#include <time.h>
#include <fcntl.h>
#include <pwd.h>
#include <grp.h>
void dec()
{
  char fname[50], ch;
  FILE *fps, *fpt;
  strcpy(fname, "login.txt");
  fps = fopen(fname, "r");
  if (fps == NULL)
  {
    printf("Error in opening file..!!");
    exit(1);
  }
  fpt = fopen("temp.txt", "w");
  if (fpt == NULL)
  {
    printf("Error in creating temp.txt file..!!");
    fclose(fps);
    exit(2);
  }
  while (1)
  {
    ch = fgetc(fps);
    if (ch == EOF)
    {
      break;
    }
    else
    {
      ch = ch + 100;
      fputc(ch, fpt);
    }
  }
  fclose(fps);
  fclose(fpt);
  fps = fopen(fname, "w");
  if (fps == NULL)
  {
    printf("Error in opening source file..!!");
    exit(3);
  }
  fpt = fopen("temp.txt", "r");
  if (fpt == NULL)
  {
    printf("Error in opening temp.txt file...!!");
    fclose(fps);
    exit(4);
  }
  while (1)
  {
    ch = fgetc(fpt);
    if (ch == EOF)
    {
      break;
    }
    else
    {
      fputc(ch, fps);
    }
  }

  fclose(fps);
  fclose(fpt);
}

int main()
{
enc();
}
